//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class App {
    public static void main(String[] args) {

        Dog myDog = new Dog("Kobe" , 24);
        System.out.println(myDog.name + " " + myDog.age);




    }
}