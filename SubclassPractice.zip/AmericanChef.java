public class AmericanChef {
    public void makeHamburger() {
        System.out.println("The american chef makes hamburgers");
    }
    public void makeSideDish(){
        System.out.println("The chef makes mac and cheese");
    }
    public void makeSpecialDish(){
        System.out.println("The american chef makes a delicious lava cake");
    }
}
