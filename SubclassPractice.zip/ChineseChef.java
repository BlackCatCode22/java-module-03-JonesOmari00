public class ChineseChef {

    public void makeSpecialDish() {
        System.out.println("The american chef makes a delicious pastry");
    }

    public void makeAdditionalDish() {
        System.out.println("The additional dish made by the chef orange chicken ");
    }

}




