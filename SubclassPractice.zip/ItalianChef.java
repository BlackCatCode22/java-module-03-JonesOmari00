public class ItalianChef {

    public void makeMainDish() {
        System.out.println("The main dish the chef makes is spaghetti and meatballs");
    }

    public void makeAppetizerDish() {
        System.out.println("The appetizer dish is fresh baked garlic cheese bread");
    }

    public void makeSpecialDish(){
        System.out.println("The special dish the chef makes is the chicken parm with red sauce and noodles");
    }

    public void makeAdditionalDish(){
        System.out.println("The additional dish made by the chef is lasagna ");
    }
}

