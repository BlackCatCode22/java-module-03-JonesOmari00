
public class SubclassPractice {
    public static void main(String[] args) {

        AmericanChef normalChef = new AmericanChef();
        normalChef.makeHamburger();
        normalChef.makeSideDish();
        normalChef.makeSpecialDish();

        ItalianChef italianChef = new ItalianChef();
        italianChef.makeMainDish();
        italianChef.makeSpecialDish();
        italianChef.makeAdditionalDish();

        ChineseChef chineseChef = new ChineseChef();

        chineseChef.makeSpecialDish();
        chineseChef.makeAdditionalDish();






    }
}