//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class App {
    public static void main(String[] args) {
        System.out.println(Cat.catCounter);

        Cat myCat = new Cat();
        myCat.meow();
        myCat.name = "Kobe";
        myCat.age = 25;

        
        System.out.println(Cat.MAX_LIVES);
        System.out.println(Cat.catCounter);

    }
}