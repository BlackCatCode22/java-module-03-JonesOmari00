public class Cat {
    public static final int MAX_LIVES = 9;

    static int catCounter = 0;
    String name;
    int age;
    int livesRemaining;

    public void meow() {
        System.out.println("meow");
    }

    public Cat() {
        catCounter++;
    }
}



